import java.util.HashMap; //8.6
import java.util.Set;

/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  The exits are labelled north, 
 * east, south, west.  For each direction, the room stores a reference
 * to the neighboring room, or null if there is no exit in that direction.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */
public class Room 
{
    public String description;
    
    private String ExitString;
    private String getExitString;
    private Room outside;
    private Room english;
    private Room math;
    private Room history;
    private Room programming;
    
    public Room northExit;
    public Room southExit;
    public Room eastExit;
    public Room westExit;
    
    private String imageName;
    private String audioName;
    private HashMap<String, Room> exits; //stores exit of this room; //8.6

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Room(String description) 
    {
        this.description = description;
        exits = new HashMap<>(); //8.6
    }

    /**
     * Define the exits of this room.  Every direction either leads
     * to another room or is null (no exit there).
     * @param north The north exit.
     * @param east The east east.
     * @param south The south exit.
     * @param west The west exit.
     */
    //public void setExits(Room north, Room east, Room south, Room west) //8.6
    //{ //8.6
     //   if(north != null) { //8.6
      //      northExit = north; //8.6
      //  } //8.6
      //  if(east != null) { //8.6
      //      eastExit = east; //8.6
      //  } //8.6
      //  if(south != null) { //8.6
       //     southExit = south; //8.6
       // } //8.6
       // if(west != null) { //8.6
      //      westExit = west; //8.6
       // } //8.6
   // }
    
    /**
     * * Define an exit from this room/
     * * @param direction The direction of the exit.
     * * @param neighbor The room in the given direction.
     */
    
     public void setExit(String direction, Room neighbor)//8.8
    {
        exits.put(direction,neighbor);
        
        



    }
    

    /**
     * @return The description of the room.
     */
    public String getDescription()
    {
        return description;
    }
    
    /*************************************************************
     * added by William H. Hooper, 2006-11-28
    *************************************************************/
    /**
     * @return a String, which hopefully contains the file name
     * of an Image file.
     */
    public String getImage()
    {
        return imageName;
    }
    
    /**
     * associate an image with this room
     * @param filename a String containing a file.
     * The file <b>must</b> reside in the media directory, 
     * and must be in a format viewable in the Java AWT.
     * Readable formats include: 
     * PNG, JPG (RGB color scheme only), GIF
     */
    public void setImage(String filename)
    {
        imageName = "media/" + filename;
    }
    
    /**
     * @return a String, which hopefully contains the file name
     * of an audio file.
     */
    public String getAudio()
    {
        return audioName;
    }
    
    /**
     * associate an audio clip with this room
     * @param filename a String containing a file.
     * The file <b>must</b> reside in the media directory, 
     * and must be in a format palyable in the Java AWT.
     * Readable formats include: 
     * WAV, AU.
     */
    public void setAudio(String filename)
    {
        audioName = "media/" + filename;
    }
    
    public void getExitString() //8.6 
    { //8.6 //
    if(northExit != null) { //8.6 
            ExitString += "north "; //8.6 
        } //8.6
    if(eastExit != null) { //8.6
            ExitString += "east "; //8.6
        } //8.6
     if(southExit != null) { //8.6
    ExitString += "south "; //8.6
    } // //8.6
    if(westExit != null) { //8.6
            ExitString += "west "; //8.6
        } ////8.6
        String returnString = "Exits: "; //8.7
        Set<String> keys = exits.keySet(); //8.7
        for(String exit: keys){ //8.7
            returnString += " " + exit; //8.7
        } //8.7
        
    }
    
    
    
    
    
    private void createRooms() //8.8
    { //8.8
        Room outside, english,math,programming,history,pe; //8.8
        english = new Room("in the english hallway"); //8.8
        math = new Room("in the english hallway"); //8.8
        programming = new Room("in the programming lab"); //8.8
        history = new Room("in the history hallway"); //8.8
        pe = new Room("in the Gym"); //8.8
        
        
        
        
        english.setExit("outside",english); //8.8
        math.setExit("up",math); //8.8 
        programming.setExit("right",programming); //8.8
        history.setExit("down",history); //8.8
        pe.setExit("left",pe); //8.8

    } //8.8
        
    /**
 * Return a long description for this room, of the form:
 * "You are in the kitchen.
 * Exits: north west"
 * @return A description of the room, including exits.
 */
public String getLongDescription() { //8.9
    return "You are " + description + ".\n" + getExitString; //8.9
} //8.9


    
    
    
}
