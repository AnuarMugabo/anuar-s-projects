
/**
 * Write a description of class Item here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Item {
 
   
    private String description;
    private int studentScore;
    private double weight;
    
  
    public Item(String description, int studentScore, double weight) {
        this.description = description;
        this.studentScore = studentScore;
        this.weight = weight;
    }
    
   
    public String getDescription() {
        return description;
    }
    
    public int getStudentScore() {
        return studentScore;
    }
    
    public double getWeight() {
        return weight;
    }
    
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public void setStudentScore(int studentScore) {
        this.studentScore = studentScore;
    }
    
    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    
}
