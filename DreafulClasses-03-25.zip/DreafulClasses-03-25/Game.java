import java.util.HashMap;


/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Game 
{
    private Parser parser;
    private Room currentRoom;
    
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        createRooms();
        parser = new Parser();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room english, math, programming, history, pe,science; //8.4
            
     
        // create the rooms
        //outside = new Room("outside the main entrance of the university");
        //theater = new Room("in a lecture theater");
        //pub = new Room("in the campus pub");
        //lab = new Room("in a computing lab");
        //office = new Room("in the computing admin office");
        
        
  
  
        english = new Room("in the English classroom"); //8.4
        math = new Room("in the Math room");  //8.4 
        programming = new Room("in the Programming lab"); //8.4
        history = new Room("in the History classroom"); //8.4
        pe = new Room("in the PE gym"); //8.4
        science = new Room ("in the science Lab"); //8.4
      
   
       
        
        
        // assign images
        //outside.setImage("deakinsign.jpg");
        //theater.setImage("lecture-hall.jpg");
        //pub.setImage("cozy-little-pub.jpg");
        //lab.setImage("computer-lab.jpg");
        //office.setImage("cluttered-office.jpg");
        
        // assign sounds
        //office.setAudio("cricket.mp3");
        
        // initialise room exits
        ///outside.setExits(null, theater, lab, pub);
        //theater.setExits(null, null, null, outside);
        //pub.setExits(null, outside, null, null);
        //lab.setExits(outside, office, null, null);
        //office.setExits(null, null, null, lab);

        
        //english.setExits(null, math, programming, history); //8.4
        //math.setExits(null, null, null, english); //8.4
        //programming.setExits(english, null, null, null); //8.4
        //history.setExits(english, null, null, pe); //8.4
        //pe.setExits(null, history, null, null);  //8.4
        
        english.setExit("outside", english); //8.8
        math.setExit("north", math); //8.8
        programming.setExit("east",programming); //8.8
        history.setExit("south",history); //8.8
        pe.setExit("west",pe); //8.8
        science.setExit("east",science); //8.8
        
        
        currentRoom = english;  // //8.4
    }

    private void printLocationInfo(){
        System.out.println("you are" + currentRoom.getDescription());
        System.out.print("Exits: ");
        if(currentRoom.northExit !=null){
            System.out.println("north ");
        }
        if(currentRoom.eastExit !=null){
            System.out.println("east ");
        }
        if(currentRoom.southExit !=null){
            System.out.println("south ");
        }
        if(currentRoom.westExit !=null){
            System.out.println("west ");
        }
        System.out.println();
        }
    
    
    
    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        println();
        //println("Welcome to the World of Zuul!");
        //println("World of Zuul is a new, incredibly boring adventure game.");
        //println("Type 'help' if you need help.");
        
         println("Welcome to High school "); //8.4
        println("Going to each classroom of The school will he"); //8.4
        println("Type 'help' if you need help."); //8.4
        println();
        println("You are " + currentRoom.getDescription()); //8.4
        printLocationInfo();//8.5
        System.out.println(currentRoom.getLongDescription());//8.10
        //print("Exits: "); //8.4
        //if(currentRoom.northExit != null) {
         //   print("north ");
        //}
        //if(currentRoom.eastExit != null) {
         //   print("east ");
        //}
        //if(currentRoom.southExit != null) {
        //    print("south ");
        //}
        //if(currentRoom.westExit != null) {
        //    print("west ");
        //}
        //println();
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private void processCommand(Command command) 
    {
        if(command.isUnknown()) {
            //println("I don't know what you mean...");
            println("I don't know Man"); //8.4
            return;
        }

        
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        println("You are lost. You are alone. You wander"); //8.4
        //println("around at the university.");
        println("at a classroom"); //8.4
        println();
        println("Your command words are:");  //8.4
        println(" go quit help");  //8.4
    }

    /** 
     * Try to go in one direction. If there is an exit, enter
     * the new room, otherwise print an error message.
     */
   /**
 * Try to go in one direction. If there is an exit, enter
 * the new room, otherwise print an error message.
 */
private void goRoom(Command command) 
{
    if(!command.hasSecondWord()) {
        println("Go where?");
        return;
    }

    String direction = command.getSecondWord();

    // Try to leave current room.
    Room nextRoom = null;
    if(direction.equals("north")) {
        nextRoom = currentRoom.northExit;
    }
    if(direction.equals("east")) {
        nextRoom = currentRoom.eastExit;
    }
    if(direction.equals("south")) {
        nextRoom = currentRoom.southExit;
    }
    if(direction.equals("west")) {
        nextRoom = currentRoom.westExit;
    }

    if (nextRoom == null) {
        println("There is sum dirt in your eye");
    }
    else {
        currentRoom = nextRoom;
        println("You are " + currentRoom.getDescription());
        print("Exits: ");
        if(currentRoom.northExit != null) {
            print("north ");
        }
        if(currentRoom.eastExit != null) {
            print("east ");
        }
        if(currentRoom.southExit != null) {
            print("south ");
        }
        if(currentRoom.westExit != null) {
            print("west ");
        }
        println();
    }
}

    private String description;
    private Room northExit;
    private Room southExit;
    private Room eastExit;
    private Room westExit;

    
    
    
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private void quit(Command command) 
    {
        if(command.hasSecondWord()) {
            println("Quit what?");
            return;
        }
        
        wantToQuit = true;  // signal that we want to quit
    }
    
    /****************************************************************
     * If you want to launch an Applet
     ****************************************************************/
    
    /**
     * @return an Image from the current room
     * @see Image
     */
    public String getImage()
    {
        return currentRoom.getImage();
    }
    
    /**
     * @return an audio clip from the current room
     * @see AudioClip
     */
    public String getAudio()
    {
        return currentRoom.getAudio();
    }
    
    /****************************************************************
     * Variables & Methods added 2018-04-16 by William H. Hooper
     ****************************************************************/
    
    private String messages;
    private boolean wantToQuit;
    
    /**
     * Initialize the new variables and begin the game.
     */
    private void start()
    {
        messages = "";
        wantToQuit = false;
        printWelcome();
    }
    
    /**
     * process commands or queries to the game
     * @param input user-supplied input
     */
    public void processInput(String input)
    {
        if(finished()) {
            println("This game is over.  Please go away.");
            return;
        }
        
        Command command = parser.getCommand(input);
        processCommand(command);
    }
    
    /**
     * clear and return the output messages
     * @return current contents of the messages.
     */
    public String readMessages()
    {
        if(messages == null) {
            start();
        }
        String oldMessages = messages;
        messages = "";
        return oldMessages;
    }
    
    /**
     * @return true when the game is over.
     */
    public boolean finished()
    {
        return wantToQuit;
    }

    /**
     * add a message to the output list.
     * @param message the string to be displayed
     */
    private void print(String message)
    {
        messages += message;
    }
    
    /**
     * add a message to the output list, 
     * followed by newline.
     * @param message the string to be displayed
     * @see readMessages
     */
    private void println(String message)
    {
        print(message + "\n");
    }
    
    /**
     * add a blank line to the output list.
     */
    private void println()
    {
        println("");
    }
}
