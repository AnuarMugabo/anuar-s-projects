import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.List;
/**
 * Demonstrates the use of a list to manage a set of objects.
 *
 * @author Java Foundations
 * @version 4.0
 */
public class POSTester
{
    /**
     * Creates and populates a Program of Study.
     * Then saves it using serialization.
     */
    public static void main(String[] args) throws IOException
    {
        ProgramOfStudy pos = new ProgramOfStudy();
        ArrayList<String>  test_co = new ArrayList<String>();
        Sort_Course sco = new Sort_Course();
        Course cos1 = new Course("CSC", 1013, "Introduction to Programming", "A-");
        Course cos = new Course("PDH", 2000, "Introduction to Programming", "A-");


        test_co.add("CS 101: Introduction to Programming  [A-]");
        test_co.add("ARCH 305: Building Analysis  [A]");
        test_co.add("FRE 110: Beginning French  [B+]");
        test_co.add("CS 320: Computer Architecture");
        test_co.add("CS 321: Operating Systems");
        test_co.add("THE 201: The Theatre Experience  [A-]");
        Comparator<Course> l;

        pos.addCourse(new Course("CS", 101, "Introduction to Programming", "A-"));
        pos.addCourse(new Course("ARCH", 305, "Building Analysis", "A"));
        pos.addCourse(new Course("GER", 210, "Intermediate German"));
        pos.addCourse(new Course("CS", 320, "Computer Architecture"));
        pos.addCourse(new Course("THE", 201, "The Theatre Experience"));


        pos.addCourse1(new Course("CS", 101, "Introduction to Programming", "A-"));
        pos.addCourse1(new Course("ARCH", 305, "Building Analysis", "A"));
        pos.addCourse1(new Course("GER", 210, "Intermediate German"));
        pos.addCourse1(new Course("CS", 320, "Computer Architecture"));
        pos.addCourse1(new Course("THE", 201, "The Theatre Experience"));





        Course arch = pos.find("CS", 320);
        pos.addCourseAfter(arch, new Course("CS", 321, "Operating Systems"));

        Course theatre = pos.find("THE", 201);
        theatre.setGrade("A-");

        Course german = pos.find("GER", 210);
        pos.replace(german, new Course("FRE", 110, "Beginning French", "B+"));

        System.out.println(pos);

        pos.save("ProgramOfStudy");

        Collections.sort(test_co);
        //Collections.sort(test_co, Collections.reverseOrder());

        // Let us print the sorted list
        System.out.println("List after sorting"
                + test_co);

        //Using Comparator in Sort_Course class


        System.out.println(sco.compare(arch,theatre));
        System.out.println(cos.compareTo(cos1));

    }
}