import java.util.Comparator;

public class Sort_Course implements Comparator<Course> {





    public int compare(Course a, Course b) {

        return a.number - b.number;
    }


}