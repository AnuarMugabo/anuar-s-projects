import java.util.Arrays;

public class StudentManager {
    private Student[] students;
    private String[] studentNames;

    public StudentManager(int numStudents) {

        this.studentNames = new String[numStudents];
    }

    public void initializeStudents() {
        for (int i = 0; i < students.length; i++) {
            studentNames[i] = "Student " + (i + 1); // Initialize student names
            students[i] = new Student(studentNames[i], 0.0); // Initialize students with default homework grade
        }
    }

    public void printStudentInfo() {
        for (int i = 0; i < students.length; i++) {
            System.out.println("Student " + (i + 1) + ": " + students[i].getName() + ", Homework Grade: " + students[i].getHomeworkGrade());
        }
    }
}