public class Student {
    private String name;
    private double homeworkGrade;

    public Student(String name, double homeworkGrade) {
        this.name = name;
        this.homeworkGrade = homeworkGrade;
    }

    public String getName() {
        return name;
    }

    public double getHomeworkGrade() {
        return homeworkGrade;
    }
}