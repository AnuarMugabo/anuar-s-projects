import java.util.HashMap;
import java.util.Map;
import java.util.Random;
/**
 * Write a description of class RPGInventory here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RPGInventory
{
    
    private String storeName;
    private String shopkeeperName;
    private Map<String, Integer> inventory;
    private String store;
    
    public RPGInventory() {
       
        this.storeName = generateRandomStoreName();
        
        this.shopkeeperName = generateRandomShopkeeperName();
        
        
        this.inventory = new HashMap<>();
    }

   
    private String generateRandomStoreName() {
        String [] storeNames  = {"Drawing World", "Pen World", "Eraser World", "Divine Domain"};
        Random random = new Random();
        return storeNames[random.nextInt(storeNames.length)];
    }

    
    private String generateRandomShopkeeperName() {
        String[] shopkeeperNames = {"Anuar", "Kevin", "Avalanche", "Kev", "Black", "Adam"};
        Random random = new Random();
        return shopkeeperNames[random.nextInt(shopkeeperNames.length)];
    }

    public String getStoreName() {
        return storeName;
    }

    public String getShopkeeperName() {
        return shopkeeperName;
    }

    public Map<String, Integer> getInventory() {
        return inventory;
    }

    
}

