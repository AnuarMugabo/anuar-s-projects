/* The IntegerLinkedList class
   Anderson, Franceschi
*/

public class IntegerLinkedList
{
  private IntegerNode head;
  private int numberOfItems;

  /** default constructor
  *   constructors an empty list
  */
  public IntegerLinkedList( )
  {
    head = null;
    numberOfItems = 0;
  }

  /** accessor for numberOfItems
  *   @return   numberOfItmes
  */
  public int getNumberOfItems( )
  {
    return numberOfItems;
  }

  /** insert method
  *   @param    value  data to  insert
  *    inserts node at head
  */
  public void insert( int value )
  {
    IntegerNode nd = new IntegerNode( value );
    nd.setNext( head );
    head = nd;
    numberOfItems++;
  }

  /** delete method
  *   @param    value   the value to delete
  *   @return   true if value was deleted, false otherwise
  */
  public boolean delete( int value )
  {
    IntegerNode current = head;
    IntegerNode previous = null;
    while ( current != null
            && current.getData( ) != value )
    {
      previous = current;
      current = current.getNext( );
    }

    if ( current == null ) // not found
      return false;
    else
    {
      if ( current == head )
        head = head.getNext( );  // delete head
      else
        previous.setNext( current.getNext( ) );

      numberOfItems--;
      return  true;
    }
  }

  /** toString
  *   @return    values in list separated by a space
  */
  @Override
  public String toString( )
  {
    String listString = "";
    IntegerNode current = head;
    for ( int i = 0; i < numberOfItems; i++ )
    {
      listString += current.getData( ) + " ";
      current = current.getNext( );
    }
    return listString;
  }

  public static void main(String[] args) {
    IntegerLinkedList list = new IntegerLinkedList();

    // Insert 10 values
    for (int i = 1; i <= 10; i++) {
      list.insert(i);
    }

    // Print the list in reverse order
    System.out.println(list.toString().trim()); // Output: 10 9 8 7 6 5 4 3 2 1
  }



}
//insert 10 values dynamically
//return in reverse order


//Describe the difference between Linked List and Array List Implementation