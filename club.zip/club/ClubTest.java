import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ClubTest.
 *
 * @author  William H. Hooper
 * @version 2012-07-03
 */
public class ClubTest
{
    private Club club1;
    private Club club2;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        club1 = new Club();
        club1.join(new Membership("Albert", 2, 2010));
        club1.join(new Membership("Betty", 1, 2010));
        
        club2 = new Club();
        club2.join(new Membership("Albert", 2, 2010));
        club2.join(new Membership("Betty", 1, 2010));
        club2.join(new Membership("Charles", 4, 2012));
        club2.join(new Membership("Debby", 3, 2011));
        club2.join(new Membership("Evan", 3, 2010));
        club2.join(new Membership("Francine", 3, 2010));
        club2.join(new Membership("George", 4, 2011));
        club2.join(new Membership("Harriet", 2, 2010));
        club2.join(new Membership("Ivan", 1, 2011));
        club2.join(new Membership("Julie", 2, 2010));
        club2.join(new Membership("Kent", 2, 2012));
        club2.join(new Membership("Lisa", 3, 2011));
        club2.join(new Membership("Matthew", 3, 2011));
        club2.join(new Membership("Nanette", 2, 2012));
        club2.join(new Membership("Oliver", 2, 2010));
        club2.join(new Membership("Pam", 2, 2010));
        club2.join(new Membership("Quentin", 4, 2011));
        club2.join(new Membership("Rose", 3, 2010));
        club2.join(new Membership("Sam", 3, 2010));
        club2.join(new Membership("Tabitha", 2, 2010));
        club2.join(new Membership("Umberto", 1, 2011));
        club2.join(new Membership("Veronica", 1, 2011));
        club2.join(new Membership("Walter", 4, 2012));
        club2.join(new Membership("Xenia", 4, 2010));
        club2.join(new Membership("Yves", 1, 2010));
        club2.join(new Membership("Zelda", 1, 2011));    
    }

    @Test
    public void number2()
    {
        assertEquals(2, club1.numberOfMembers());
    }

    @Test
    public void number26()
    {
        assertEquals(26, club2.numberOfMembers());
    }

/**************************************************
 * Tests for Exercise 4.54
 * The following tests should compile and pass
 * when you have correctly defined the joinedInMonth 
 * method in the Club class.
 **************************************************/
    
//     @Test
//     public void joined1()
//     {
//         assertEquals(1, club1.joinedInMonth(1));
//     }
// 
//     @Test
//     public void joined3()
//     {
//         assertEquals(7, club2.joinedInMonth(3));
//     }
// 
//     @Test
//     public void joined11()
//     {
//         assertEquals(0, club2.joinedInMonth(11));
//     }
// 
//     @Test
//     public void joined13()
//     {
//         assertEquals(0, club1.joinedInMonth(13));
//     }

/**************************************************
 * Tests for Exercise 4.55
 * The following tests should compile and pass
 * when you have correctly defined the purge method
 * in the Club class.
 **************************************************/
    
//     @Test
//     public void purgeY2010M1()
//     {
//         assertEquals(26, club2.numberOfMembers());
//         club1.purge(1, 2010);
//         assertEquals(24, club2.numberOfMembers());
//     }
// 
//     @Test
//     public void purgeY2010M2()
//     {
//         assertEquals(26, club2.numberOfMembers());
//         club1.purge(2, 2010);
//         assertEquals(21, club2.numberOfMembers());
//     }
// 
//     @Test
//     public void purgeY2010M7()
//     {
//         assertEquals(26, club2.numberOfMembers());
//         club1.purge(7, 2010);
//         assertEquals(26, club2.numberOfMembers());
//     }

}

