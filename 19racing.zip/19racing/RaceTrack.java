
import cha.*;
import cha.action.*;
import java.awt.*;
import java.util.*;

import static java.lang.Math.*;
import static java.awt.Color.*;

public class RaceTrack
extends CHApplet {
    Racer tortoise;
    //  Step 1: Declare your hare Racer here
    Judge judge;

    private class Setup
    extends CHAction {
        public void step() {
            judge = new Judge(1);
            tortoise.setJudge(judge);            
            tortoise.start();
        }
    }

    private class Starter
    extends CHAction {
        public void step() {
            judge.start();
        }
    }

    public void init() {

        setBackground(green);

        int start;
        start = 150;

        CHRectangle startingLine;
        startingLine = new CHRectangle();
        add(startingLine);
        startingLine.setBounds(start, 50, 10, 140);
        startingLine.setBackground(white);

        int finish;
        finish = 700;

        Color brown;
        brown = new Color(102, 102, 0);

        CHRectangle track;
        track = new CHRectangle();
        add(track);
        track.setBounds(0, 50, finish, 140);
        track.setBackground(brown);

        CHImage tImage;
        tImage = new CHImage();
        add(tImage, 0);
        tImage.setFile("turtle.png");

        CHLabel tLabel;
        tLabel = new CHLabel();
        add(tLabel);

        tortoise = new Racer();
        add(tortoise);
        tortoise.setImage(tImage);
        tortoise.setStart(start, 100);
        tortoise.setFinish(finish);
        tortoise.setLabel(tLabel);

        // Step 2: Declare, create, and add the hare image here.

        // Step 3: Declare and add the label for the hare here.

        // Step 4:  Create, add, setImage, setLabel, setStart 
        //          and setFinish for your hare Racer here.

        Starter startAction;
        startAction = new Starter();
        add(startAction);
        startAction.setText("Go!");

        CHButton startButton;
        startButton = new CHButton();
        add(startButton);
        startButton.setAction(startAction);
        startButton.setBounds(150, 200, 60, 25);        

        Setup setAction;
        setAction = new Setup();
        add(setAction);
        setAction.setText("Get Set...");
        setAction.step();

    } // end of init - DO NOT REMOVE

    /***********************************************************
     * DO NOT Change the code below this line.
     ***********************************************************/
    public static void run() {
        int width = 800;
        int height = 230;
        CHApplet applet = new RaceTrack(); 
        applet.run(width, height);
    }

    private RaceTrack(){}
}
