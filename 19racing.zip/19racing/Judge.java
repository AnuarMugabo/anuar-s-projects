import java.util.*;

public class Judge
{
    private int place;
    private int lastPlace;
    private boolean go;
    private Random pacer;
    
    public Judge(int howMany)
    {
        place = 1;
        lastPlace = howMany;
        go = false;
        pacer = new Random();
    }
    
    public void start()
    {
        go = true;
    }
    
    public boolean signal()
    {
        return go;
    }
    
    public Random getPacer()
    {
        return pacer;
    }
    
    public boolean done()
    {
        return place > lastPlace;
    }
    
    public void waitUntilDone() {
        while(!done()) {
            try {
                Thread.sleep(30);
            } catch (Exception e) { }
        }
    }
    
    public synchronized String prize()
    {
        return (place++) + "";
    }
}
