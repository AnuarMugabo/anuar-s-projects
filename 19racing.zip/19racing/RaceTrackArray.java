
import cha.*;
import cha.action.*;
import java.awt.*;
import java.util.*;

import static java.lang.Math.*;
import static java.awt.Color.*;

public class RaceTrackArray
extends CHApplet {
    Racer dogs;
    Judge judge;

    
    private class Setup
    extends CHAction {
        public void step() {
            judge = new Judge(1);

            dogs.setJudge(judge);
            dogs.start();//             }
        }
    }
    
    private class Starter
    extends CHAction {
        public void step() {
            judge.start();
        }
    }
    
    public void init() {
        
        setBackground(green);
        
        int start;
        start = 150;
        
        CHRectangle startingLine;
        startingLine = new CHRectangle();
        add(startingLine);
        startingLine.setBounds(start, 50, 10, 200);
        startingLine.setBackground(white);
        
        int finish;
        finish = 700;
        
        CHRectangle finishLine;
        finishLine = new CHRectangle();
        add(finishLine);
        finishLine.setBounds(finish, 50, 10, 200);
        finishLine.setBackground(white);
        
        Color brown;
        brown = new Color(102, 102, 0);
        
        CHRectangle track;
        track = new CHRectangle();
        add(track);
        track.setBounds(0, 50, finish, 200);
        track.setBackground(brown);
        
        CHImage dImage;
        dImage = new CHImage();
        add(dImage, 0);
        dImage.setFile("dog.png");
            
        CHLabel dLabel;
        dLabel = new CHLabel();
        add(dLabel);
            
        dogs = new Racer();
        add(dogs);
        dogs.setImage(dImage);
        dogs.setStart(start, 100);
        dogs.setFinish(finish);
        dogs.setLabel(dLabel);
        
        Starter startAction;
        startAction = new Starter();
        add (startAction);
        startAction.setText("Go!");
        
        CHButton startButton;
        startButton = new CHButton();
        add(startButton);
        startButton.setAction(startAction);
        startButton.setBounds(150, 270, 60, 25);
        
        Setup setAction;
        setAction = new Setup();
        setAction.setText("Get Set...");
        setAction.step();

    } // end of init - DO NOT REMOVE
    
    /***********************************************************
     * DO NOT change the code below this line.
     ***********************************************************/
    public static void run() {
        int width = 800;
        int height = 300;
        CHApplet applet = new RaceTrackArray(); 
        applet.run(width, height);
    }
    
    private RaceTrackArray(){}
}
