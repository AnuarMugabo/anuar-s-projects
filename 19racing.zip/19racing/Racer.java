
import cha.*;
import cha.action.*;
import java.awt.*;
import java.util.*;

import static java.lang.Math.*;
import static java.awt.Color.*;

public class Racer
extends CHAction {
    double startX;
    double finishX;
    double finishY;
    double x;
    double y;

    CHComponent image;
    CHClip sound;
    Random gen;
    Judge judge;
    boolean ready;
    CHLabel place;
    
    public void setImage(CHComponent i) {
        image = i;
    }
    
    public void setStart(int sx, int sy) {
        startX = sx - image.getWidth();
        x = 0;
        y = sy - image.getHeight();
        image.setLocation(x, y);
        finishY = sy;
    }
    
    public void setFinish(int fx) {
        finishX = fx - image.getWidth();
        
        // approx.length of race
        int delay = 100;    // milliseconds
        int duration = 20;  // seconds
        setDelay(delay);    
    }
    
    public void setLabel(CHLabel p) {
        place = p;
        place.setText("_");
        double lx;
        lx = finishX + image.getWidth() + 30;
        double ly;
        ly = finishY - place.getHeight();
        place.setLocation(lx, ly);
    }
    
    public void setJudge(Judge j) {
        judge = j;
    }
    
    public void run()   {
        gen = new Random();
        
        // wait for the signal
        while (!judge.signal())  {
            ready = true;
            sleep();
        }
        
        // start at the start line
        x = startX;
        image.setLocation(x, y);        
        place.setText("_");
        
        // run to the finish
        while (x < finishX)   {
            x = x + 3;
            image.setLocation(x, y);
            sleep();
        }
        
        // claim the prize
        place.setText(judge.prize());
    }
}
