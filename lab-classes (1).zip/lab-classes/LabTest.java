import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * LabTest - create a sample lab class.
 *
 * @author  William h. Hooper
 * @version 2018-02-21
 */
public class LabTest
{
    private LabClass labClass1;
    private LabClass labClass2;
    private Student student1;
    private Student student2;
    private Student student3;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        System.out.print('\f');
        labClass1 = new LabClass(4);
        student1 = new Student("Albert", "B001");
        student2 = new Student("Betty", "B002");
        student3 = new Student("Charles", "B003");
        labClass1.enrollStudent(student1);
        labClass1.enrollStudent(student2);
        labClass1.enrollStudent(student3);
        labClass1.printList();
        
        labClass2 = new LabClass(28);
        labClass2.enrollStudent(student1);
        labClass2.enrollStudent(student2);
        labClass2.enrollStudent(student3);
        labClass2.enrollStudent(new Student("Diane", "B004"));
        labClass2.enrollStudent(new Student("Edgar", "B5"));
        labClass2.enrollStudent(new Student("Fiona", "B006"));
        labClass2.enrollStudent(new Student("George", "B007"));
        labClass2.enrollStudent(new Student("Hermione", "B8"));
        labClass2.enrollStudent(new Student("Ian", "B9"));
        labClass2.enrollStudent(new Student("Jo", "B010"));
        labClass2.enrollStudent(new Student("Kelly", "B011"));
        labClass2.enrollStudent(new Student("Lisa", "B012"));
        labClass2.enrollStudent(new Student("Marty", "B013"));
        labClass2.enrollStudent(new Student("Nell", "B014"));
        labClass2.enrollStudent(new Student("Oliver", "B015"));
        labClass2.enrollStudent(new Student("Patty", "B016"));
        labClass2.enrollStudent(new Student("Quentin", "B017"));
        labClass2.enrollStudent(new Student("Rachel", "B018"));
        labClass2.enrollStudent(new Student("Sam", "B019"));
        labClass2.enrollStudent(new Student("Tina", "B020"));
        labClass2.enrollStudent(new Student("Uriah", "B021"));
        labClass2.enrollStudent(new Student("Vera", "B022"));
        labClass2.enrollStudent(new Student("Walter", "B023"));
        labClass2.enrollStudent(new Student("Xenia", "B024"));
        labClass2.enrollStudent(new Student("Yo", "B025"));
        labClass2.enrollStudent(new Student("Zahar", "B026"));
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
