
import cha.*;
import java.awt.*;

import static java.awt.Color.*;

public class Bird
extends CHContainer{

    public void init() {
        
        CHArc top;
        top = new CHArc();
        add(top);
        top.setBounds(0, 0, 32, 16);
        top.setArc(15, 150);
        top.setBackground(black);
        
        CHArc ltWing;
        ltWing = new CHArc();
        add(ltWing, 0);
        ltWing.setBounds(0, 4, 16, 8);
        ltWing.setArc(0, 165);
        ltWing.setBackground(white);
        
        CHArc rtWing;
        rtWing = new CHArc();
        add(rtWing, 0);
        rtWing.setBounds(16, 4, 16, 12);
        rtWing.setArc(15, 165);
        rtWing.setBackground(white);
        
    }
}
