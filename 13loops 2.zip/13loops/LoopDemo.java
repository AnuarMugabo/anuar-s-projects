
import cha.*;
import cha.action.*;
import java.awt.*;
import java.util.*;

import static java.awt.Color.*;

public class LoopDemo
extends CHApplet {
    CHOval ball;
    Random gen;
    CHLabel name;
    
    private class Flight
    extends CHAction {
        public void run() {
            
            ball.setAcceleration(-0.02,0.07);
            ball.setVelocity(-1,-2);
            
            for(int i = 0; i < limit; i++) {
                ball .moveOneStep();
                sleep();
            } 
            ball.setAcceleration(-0.01,0.03);
            ball.setVelocity(-1,-2);
            for(int i = 0; i < limit; i++) {
               ball .moveOneStep();
                sleep();
            } 
            for(int i = 0; i < limit; i++) {
                ball.setLocation(450,340);
            } 

        }
    }
    
    public void init() {
        
        CHLabel name;
        name= new CHLabel();
        add(name);
        name.setText("Om and Yahye");
        name.setBounds(350,410,100,100);
        name.setForeground(red);
        
        ball = new CHOval();
        add(ball);
        ball.setBounds(420,320,20,20);
        ball.setBackground(yellow);
        //---Flight
        Flight flight;
        flight = new Flight();
        add(flight);
        flight.setText("l.");
        flight.setLimit(100);
        
        CHButton button;
        button = new CHButton();
        add(button);
        button.setBounds(300,300, 87,29);
        button.setAction(flight);
    

        CHLabel aLabel;
        aLabel = new CHLabel();
        add(aLabel);
        aLabel.setText("a.");
        aLabel.setBounds(10, 10, 20, 20);
        
        
         for(int i = 0; i < 5; i++) {
            CHOval oval;
            oval = new CHOval();
            add(oval);
            int y = 30 + i * 20;
            oval.setBounds(30, y, 25, 20);
        }
        
        CHLabel bLabel;
        bLabel = new CHLabel();
        add(bLabel);
        bLabel.setText("b.");
        bLabel.setBounds(90, 10, 20, 20);
        
        // put statements to create rectangles here
        for(int i = 0; i < 4; i++) {
            CHRectangle rec;
            rec= new CHRectangle ();
            add(rec);
            
            int x = 85 + i * 15;
            rec.setBounds(x,40,10,40);
        }
        // each with different x coordinates

        
        // put statements here to create the c label
        CHLabel cLabel;
        bLabel = new CHLabel();
        add(bLabel);
        bLabel.setText("c.");
        bLabel.setBounds(170, 10, 20, 20);
        for(int i = 0; i < 6; i++) {
            CHOval oval2;
            oval2 = new CHOval();
            add(oval2);
            
            int y = 30 + i * 15;
            
            int x = 180 + i * 10;
            oval2.setBounds(x, y, 17, 17);
        }
        // then loop code to change both the x and y coords

         
        CHLabel dLabel;
        dLabel = new CHLabel();
        add(dLabel);
        dLabel.setText("d.");
        dLabel.setBounds(260, 10, 20, 20);
        
        // put statements to create rectangles here
        for(int i = 0; i < 5; i++) {
            CHRectangle rec;
            rec= new CHRectangle ();
            add(rec);
            
            int y = 85 + i * -10;
           
            int x = 270 + i * 10;
            rec.setBounds(x,y,50,10);
        }


        CHLabel eLabel;
        eLabel = new CHLabel();
        add(eLabel);
        eLabel.setText("e.");
        eLabel.setBounds(370, 10, 20, 20);
        for(int i = 0; i < 4; i++) {
            CHOval oval2;
            oval2 = new CHOval();
            add(oval2);
            
            int y = 50 + i * 20;
           
            
            int x = 370 + i * 20;
            
            
            int h = 60 + i  * -8;
            
            oval2.setBounds(x, h, 20, y);
        }
        
        CHLabel fLabel;
        fLabel = new CHLabel();
        add(fLabel);
        fLabel.setText("f.");
        fLabel.setBounds(10, 150, 20, 20);
        
          
         for (int i = 0; i < 11; i++) {

        
            CHLine line = new CHLine();
            add(line);
    
            
            int x = 85 - i * 5; 
          
            int y1 = 250 - i * 10;
        
            
            line.addPoint(x, y1);  // Starting point (x, y1)
            line.addPoint(x,250);
            
        }
        
        CHLabel gLabel;
        gLabel = new CHLabel();
        add(gLabel);
        gLabel.setText("g.");
        gLabel.setBounds(100, 150, 20, 20);
        
        for(int i = 0; i < 7; i++) {
            CHLine line;
            line = new CHLine();
            add(line);
           
            int x = 160 - i * 10;
            
            int y = 250 - i * 10;
            
            int x2= 100 + i * 10;

            line.addPoint(x, y);
            line.addPoint(x2, y);
        }
        
        CHLabel hLabel;
        hLabel = new CHLabel();
        add(hLabel);
        hLabel.setText("h.");
        hLabel.setBounds(200, 150, 20, 20);
        
        for(int i = 0; i < 5; i++) {
            CHRectangle rectangle2;
            rectangle2 = new CHRectangle();
            add(rectangle2);
            
            int x = 200 + i *0;
            
            int y = 170 + i *0;
            
            int w = 20 + i * 10;
             
            int h = 40 + i * 10;
            rectangle2.setBounds(x, y, w, h);
            rectangle2.setBackground(blue);
        }
        
        CHLabel iLabel;
        iLabel = new CHLabel();
        add(iLabel);
        iLabel.setText("i.");
        iLabel.setBounds(300, 150, 20, 20);
        
       
        for(int i = 0; i < 4; i++) {
            CHOval oval4;
            oval4 = new CHOval();
            add(oval4);
            
            int x = 350 - i * 10;
           
            int y = 200 - i * 10;
          
            int w = 20 + i * 20;
            
            int h = 20 + i * 20;
            oval4.setBounds(x, y, w, h);
            Color color;
            
            int r = 250 - i * 80;
         
            int g = 130 + i * 30;
            color = new Color(r,g,0);
            oval4.setBackground(color);
            
        }
        
        CHLabel jLabel;
        jLabel = new CHLabel();
        add(jLabel);
        jLabel.setText("j.");
        jLabel.setBounds(10, 320, 20, 20);
        
        Random gen;
        gen = new Random();
        
        for(int i = 0; i < 50; i++) {
           CHOval Star;
           Star = new CHOval();
           add(Star);
            int x = gen.nextInt(100)+ 30;
           int y = gen.nextInt(100)+ 340;
           Star.setBounds(x,y,1,1);
           Star.setForeground(yellow);
           Star.setBackground(yellow);
           
            CHRectangle rectangle;
        rectangle = new CHRectangle();
            add(rectangle);
            rectangle.setBounds(30,340,100,100);
            rectangle.setBackground(black);

        }
        
                
        CHLabel kLabel;
        kLabel = new CHLabel();
        add(kLabel);
        kLabel.setText("k.");
        kLabel.setBounds(150, 300, 30, 30);
        
        for(int i = 0; i < 5; i++) {
           Bird bird;
           bird = new Bird();
           add(bird);
            int x;
            x = 170 + i * 13;
            int y;
            y = 340 + i * 10;
            bird.setBounds(x, y, 20, 10);
        }
        
        for(int i = 0; i < 4; i++) {
           Bird bird2;
           bird2 = new Bird();
           add(bird2);
            int x;
            x = 235 + i * 13;
            int y;
            y = 370 - i * 10;
            bird2.setBounds(x, y, 20, 10);
        }
        
        CHLine bottom;
        bottom = new CHLine();
        add(bottom);
        bottom.addPoint(0, 492);
        bottom.addPoint(500, 492);
        
                
    } // end of init - DO NOT REMOVE
    
    /***********************************************************
     * DO NOT Change the code below this line.
     ***********************************************************/
    public static void run() {
        int width = 500;
        int height = 500;
        CHApplet applet = new LoopDemo(); 
        applet.run(width, height);
    }
    
    private LoopDemo(){}
}
