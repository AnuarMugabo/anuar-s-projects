/* Name: Anuar Mugabo
# Date: 10/8/2024
# Class: CSC 1120
# Pledge: I have neither given nor received unauthorized aid on this
program.

Description: This main method in the BankingWithInheritance class is a simulation
of a banking system that allows users to interact with three types of accounts:
Savings, Checking, and CreditCard.
The program presents a menu-driven interface
that enables users to perform various transactions,
such as deposits, withdrawals, writing checks, making credit card payments,
and displaying account information.

# Input:The user types commands such as:
1: To make a deposit into the Savings account. The user will be prompted to enter the deposit amount.
2: To make a withdrawal from the Savings account. The user will be prompted to enter the withdrawal amount.
3: To make a deposit into the Checking account. The user will be prompted to enter the deposit amount.
4: To write a check from the Checking account. The user will be prompted to enter the check number and the check amount.
5: To make a payment on the CreditCard account. The user will be prompted to enter the payment amount.
6: To make a charge on the CreditCard account. The user will be prompted to enter the charge description and the charge amount.
7: To display the Savings account information, including the account balance, withdrawal record, and deposit record.
8: To display the Checking account information, including the account balance, check register, and deposit record.
9: To display the CreditCard account information, including the account balance, charges, and deposit record.
10: To exit the program.
# Output:
Checking balance: $100.0
Savings balance: $100.0
Credit Card balance: $100.0
1. Savings Deposit
2. Savings withdrawal
3. Checking Deposit
4. Write A Check
5. Credit Card Payment
6. Make A Charge
7. Display Savings
8. Display Checking
9. Display Credit Card
10. Exit
Enter your choice:
*/

public class BankingWithInheritance {
    public static void main(String[] args) {


        ///
        Savings savingsAccount = new Savings("Anuar Mugabo", 123456789, 100.0);
        Checking checkingAccount = new Checking("Avalanche", 987654321, 100.0);
        CreditCard creditCardAccount = new CreditCard("Kevin", 111111111, 100.0);
        System.out.println("***********************************");
        System.out.println("\t\t\t\t\t\t\t                Anuar Banking LLC Financial Services. \t\t");
        System.out.println("************************************");

        int choice = 10;
        do {
            System.out.println("Checking balance: $" + checkingAccount.getBalance());
            System.out.println("Savings balance: $" + savingsAccount.getBalance());
            System.out.println("Credit Card balance: $" + creditCardAccount.getBalance());
            System.out.println("MENU");
            System.out.println("1. Savings Deposit");
            System.out.println("2. Savings withdrawal");
            System.out.println("3. Checking Deposit");
            System.out.println("4. Write A Check");
            System.out.println("5. Credit Card Payment");
            System.out.println("6. Make A Charge");
            System.out.println("7. Display Savings");
            System.out.println("8. Display Checking");
            System.out.println("9. Display Credit Card");
            System.out.println("10. Exit");

            System.out.print("Enter your choice: ");
            try {
                choice = Integer.parseInt(System.console().readLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter deposit amount: ");
                    try {
                        savingsAccount.makeDeposit(Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid amount.");
                    }
                    break;
                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    try {
                        savingsAccount.doWithdraw(Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid amount.");
                    }
                    break;
                case 3:
                    System.out.print("Enter deposit amount: ");
                    try {
                        checkingAccount.makeDeposit(Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid amount.");
                    }
                    break;
                case 4:
                    System.out.print("Enter check number: ");
                    try {
                        int checkNumber = Integer.parseInt(System.console().readLine());
                        System.out.print("Enter check amount: ");
                        checkingAccount.writeCheck(checkNumber, Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid check number and amount.");
                    }
                    break;
                case 5:
                    System.out.print("Enter payment amount: ");
                    try {
                        creditCardAccount.makePayment(Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid payment amount.");
                    }
                    break;
                case 6:
                    System.out.print("Enter charge description: ");
                    String chargeDescription = System.console().readLine();
                    System.out.print("Enter charge amount: ");
                    try {
                        creditCardAccount.debitCharge(chargeDescription, Double.parseDouble(System.console().readLine()));
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid charge amount.");
                    }
                    break;
                case 7:
                    savingsAccount.display();
                    break;
                case 8:
                    checkingAccount.display();
                    break;
                case 9:
                    creditCardAccount.display();
                    break;
                case 10:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 10);
    }
}