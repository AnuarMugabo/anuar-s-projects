public class Checking extends Account {
    private int[] last10checks = new int[10];

    public Checking() {}

    public Checking(String name, int taxID, double balance) {
        super(name, taxID, balance);
    }

    public void writeCheck(int checknum, double amount) {
        balance -= amount;
        last10withdraws[numwithdraws % 10] = amount;
        numwithdraws++;
        last10checks[numwithdraws % 10] = checknum;
    }

    public void display() {
        super.display();
        System.out.println("Check Register:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Check " + last10checks[i] + ": " + last10withdraws[i]);
        }
        System.out.println("Deposit Record:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Deposit " + i + ": " + last10deposits[i]);
        }
    }
}