public class CreditCard extends Account {
    private int cardnumber;
    private String[] last10charges = new String[10];

    public CreditCard() {
    }

    public CreditCard(String name, int taxID, double balance) {
        super(name, taxID, balance);
    }

    public void debitCharge(String name, double amount) {
        balance -= amount;
        last10withdraws[numwithdraws % 10] = amount;
        numwithdraws++;
        last10charges[numwithdraws % 10] = name;
    }

    public void makePayment(double amount) {
        balance += amount;
        last10deposits[numdeposits % 10] = amount;
        numdeposits++;
    }

    public void display() {
        super.display();
        System.out.println("Charges:");
        for (int i = 0; i < 10; i++) {
            System.out.println(last10charges[i] + ": " + last10withdraws[i]);
        }
        System.out.println("Deposit Record:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Deposit " + i + ": " + last10deposits[i]);
        }
    }
}
