public class Account {
    protected String name;
    protected int taxID;
    protected double balance;
    protected double[] last10withdraws = new double[10];
    protected double[] last10deposits = new double[10];
    protected int numdeposits = 0;
    protected int numwithdraws = 0;

    public Account() {}

    public Account(String name, int taxID, double balance) {
        this.name = name;
        this.taxID = taxID;
        this.balance = balance;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTaxID(int taxID) {
        this.taxID = taxID;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public int getTaxID() {
        return taxID;
    }

    public double getBalance() {
        return balance;
    }

    public void makeDeposit(double amount) {
        balance += amount;
        last10deposits[numdeposits % 10] = amount;
        numdeposits++;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Tax ID: " + taxID);
        System.out.println("Balance: " + balance);
    }
}