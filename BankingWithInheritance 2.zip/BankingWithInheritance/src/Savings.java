public class Savings extends Account {
    public  Savings() {}

    public Savings(String name, int taxID, double balance) {
        super(name, taxID, balance);
    }

    public void doWithdraw(double amount) {
        balance -= amount;
        last10withdraws[numwithdraws % 10] = amount;
        numwithdraws++;
    }

    public void display() {
        super.display();
        System.out.println("Withdrawal Record:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Withdrawal " + i + ": " + last10withdraws[i]);
        }
        System.out.println("Deposit Record:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Deposit " + i + ": " + last10deposits[i]);
        }
    }
}