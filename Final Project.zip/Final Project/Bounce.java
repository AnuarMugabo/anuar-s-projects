import cha.*;
import cha.action.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.text.DecimalFormat;
import java.util.*;
import javax.imageio.*;

import static java.awt.Color.*;
import static java.awt.Font.*;
import static java.lang.Math.*;
import static javax.swing.SwingConstants.*;


public class Bounce 
extends CHApplet{ 
    
    CHOval [] ornament;
    CHOval [] ornament2;
    CHOval [] ornament3;
    CHOval [] ornament4;
    CHOval [] ornament5;
    CHOval [] ornament6;
    CHArc Moon;
     CHOval [] stars;
     CHImage kirbyy;
     //double SPEEDdX;
     //double SPEEDdY;
     char length;
     int count;
     int Maximum;
    CHLabel score1;
    Random gen;
    Color blue;
    Rectangle toprect;
    Rectangle bottomrect;
    CHImage LavaFlow2;
    Jump jAction;
    CHClip jumpSound;
     CHClip gameOver;
      int vel = 1;
   // CHRectangle upbound;
    class moveornament
    extends CHAction {
    public void before() {
         for(int i = 0; i < ornament.length; i++) {
                 //ornament.moveOneStep();
                 ornament[i].setVelocity(3,0);  
                 ornament2[i].setVelocity(3,0);  
    
        }  
            //kirbyy.setAcceleration(0,0);
            //kirbyy.setVelocity(0,-20);
        }
        public void step() {
         for(int i = 0; i < ornament.length; i++) {
                ornament[i].moveOneStep();
         ornament2[i].moveOneStep();  
         if(ornament[i].x > 1000 || ornament[i].x < 0)
         if(ornament2[i].x > 1000 || ornament2[i].x < 0) {                                       {
                 vel = vel * - 1;
                 ornament[i].setVelocity(vel*3,0);
                 ornament2[i].setVelocity(vel*3,0);
                 
                 
                 
                }
                }
                // ornament.setVelocity(10,0);  
                 
             //CHOval ornament;
        
            
        
        
            
          
        }
        
         
        
        
        
    } public void after() {
               
            
            //ornament2.setVelocity(4,0);
        
            
        }
    }
    
   class Jump
    extends CHAction {
        
         public void before() {
            jumpSound.play();
             kirbyy.setVelocity(0,-2);
            //kirbyy.setAcceleration(0,0);
            //kirbyy.setVelocity(0,-20);
        }
        
        public void step() {
            kirbyy.moveOneStep();
            //ornament2.moveOneStep();
           // if(ornament2 == blue) {
            //ornament2.setVelocity(4,0);  
                //jumpSound.play();
             gameOver.play();
            //}
            
            //ornament2.setVelocity(4,0);
            //for(int i = 0; i < 26; i++) {
            //CHOval ornament;
            // ornament2.setVelocity(4,0);
            //vel = 4;

        //}
            //Maximum = 100;
            
            
            
            count = count +1;
            //Rectangle upBounds;
           // upBounds = top.getBounds();
            
             Rectangle xp;
             xp = kirbyy.getBounds();
            
            if(toprect.intersects(xp)) {
            //kirbyy.stop();
            kirbyy.setVelocity (0,1);
             //kirbyy.setLocation(380, 320);
        }
          if( bottomrect.intersects(xp)) {
            jAction.stop();
            kirbyy.setVelocity (0,1);
             kirbyy.setLocation(380, 320);
             jAction.stop();
            count = 0;
            score1.setText("Score:" + count);

        }
        }
        public void after() {
            
            count = count +1;
            
            score1.setText("Score:" + count);
            //kirbyy.setVelocity(0,-20);
            //ornament2.setVelocity(4,0);
           
                          
            
        }
        //public void before() {
            //kirbyy.setVelocity(0,4);
            //kirbyy.setAcceleration(0,-0.5);
        //}
    }
    class Reset
    extends CHAction {
        public void step() {
            
            kirbyy.setLocation(380, 220);
            jAction.stop();
            count = 0;
            score1.setText("Score:" + count);
            

            //Reset.moveOneStep();
            //CHRectangle upbound;

            //Rectangle up = upbound.getBounds();
            
            
        
        }
        public void after() {
            
        }
        public void before() {
            kirbyy.setVelocity(1,2);
            kirbyy.setAcceleration(0,-1.3);
            //ornament.setVelocity(1,2);
            //ornament.setAcceleration(0,-1.3);
        }
    }

    public void init() {
       gen = new Random(); 
        
        //CHImage kirbyy;
        kirbyy = new CHImage();
        add(kirbyy);
        kirbyy.setFile("kirbyy.png");
        kirbyy.setBounds(380, 320, 80, 120);
        
        kirbyy.setVelocity(0,-2);
        
        //vel = 4;
       
        Maximum = 100;
        
            stars = new CHOval[100];
        for (int i=0; i<stars.length; i++){
            stars[i] = new CHOval();
            int x = gen.nextInt(800);
            int y = gen.nextInt(480);
            add(stars[i]);
            stars[i].setBounds(x, y, 3, 3);
            
            stars[i].setBackground(red);
            stars[i].setForeground(red);
        }
         

            stars = new CHOval[100];
        for (int i=0; i<stars.length; i++){
            stars[i] = new CHOval();
            int x = gen.nextInt(800);
            int y = gen.nextInt(480);
            add(stars[i]);
            stars[i].setBounds(x, y, 6, 6);
            stars[i].setBackground(blue);
            stars[i].setForeground(blue);
        }
         
       
        
        
          jumpSound = new CHClip();
        add(jumpSound);
        jumpSound.setFile("jump-sound.wav");
        
        gameOver = new CHClip();
        add(gameOver);
        gameOver.setFile("game-over.wav");
        
        CHRectangle top;
        top = new CHRectangle();
        add(top);
        top.setBounds(0,0,900,10);
        toprect = top.getBounds();
        top.setBackground(white);
        //top.setInvisible;
      //(startAction);
        //Color lightgreen;
        //lightgreen = new Color (144, 238, 144);
        //setBackground(lightgreen);
         
        //CHImage MagmaLava;
        //MagmaLava = new CHImage();
        //add(MagmaLava,0);
        //MagmaLava.setFile("MagmaLava.Png");
        //MagmaLava.setBounds(50, 200, 700, 1000);
            
         //CHButton startButton;
       // startButton = new CHButton();
       //add(startButton);
       // startButton.setAction
       // startButton.setBounds(237, 16, 75, 29);

       //  CHButton jumpButton;
       // jumpButton = new CHButton();
      //  add(jumpButton);
       // jumpButton.setAction(jumpAction);
       // jumpButton.setBounds(237, 16, 75, 29);
        
        //Color blue;
        blue = new Color(0,150,155);
       
         Color red;
        red = new Color (139, 0, 0);
        
        Color green;
        green = new Color(0,128,0);
        
       
       Color  Transperant;
        Transperant = new Color(10, 10, 100, 100);
        
        Color  Transperant2;
        Transperant2 = new Color(255, 255, 255, 128);
       
         
        ornament = new CHOval[11];
        for(int i = 0; i < ornament.length; i++) {
            //CHOval ornament;
        ornament[i] = new CHOval();
        add(ornament[i],0);
        
        
        int y = 5 + i * 50;
        
        ornament[i].setBounds(0,y,20,20);
        ornament[i].setForeground(red);
        ornament[i].setBackground(red);
            
        
        
            
          
        }
        ornament2 = new CHOval[11];
        for(int i = 0; i < ornament2.length; i++) {
            //CHOval ornament;
        ornament2[i] = new CHOval();
        add(ornament2[i],0);
        
        
        int y = 25 + i * 50;
        
        ornament2[i].setBounds(0,y,20,20);
        ornament2[i].setForeground(blue);
        ornament2[i].setBackground(blue);
            
        
        
            
          
        }
       
    //   if (score1 >= 100) {
//    score1 = 0;
   // kirbyy.setBounds(380, 320, 80, 120);


         CHImage LavaFlow2;
        LavaFlow2 = new CHImage();
        add(LavaFlow2,0);
        LavaFlow2.setFile("LavaFlow2.Png");
        LavaFlow2.setBounds(0, 550, 900, 601);
        bottomrect = LavaFlow2.getBounds();   
        
       
         //CHImage lava2;
        //lava2 = new CHImage();
        //add(lava2);
        //lava2.setFile("lava2.png");
        //lava2.setBounds(-70, 700, 1300, 371);

         CHImage greenbackground;
        greenbackground = new CHImage();
        add(greenbackground);
        greenbackground.setFile("greenbackground.png");
        greenbackground.setBounds(-103, -10, 1206, 1106);
            
       
   CHPolygon triangle = new CHPolygon();
    add(triangle, 0);
    triangle.addPoint(540, 200); // Updated x-coordinate by adding 20 to the previous x-coordinate
    triangle.addPoint(640, 200); // Updated x-coordinate by adding 20 to the previous x-coordinate
    triangle.addPoint(590, 110); // Updated x-coordinate by adding 20 to the previous x-coordinate
    triangle.setForeground(green);
    triangle.setBackground(green);
    

        
        
        CHOval ornament3;
        ornament3 = new CHOval();
        add(ornament3,0);
        ornament3.setBounds(580,120,20,20); 
        ornament3.setForeground(red);
        ornament3.setBackground(red);
         
        CHOval ornament4;
        ornament4 = new CHOval();
        add(ornament4,0);
        ornament4.setBounds(580,140,20,20);
        ornament4.setForeground(blue);
        ornament4.setBackground(blue);
        
        
         CHOval ornament5;
        ornament3 = new CHOval();
        add(ornament3,0);
        ornament3.setBounds(580,160,20,20); 
        ornament3.setForeground(red);
        ornament3.setBackground(red);
         
        
         CHOval ornament6;
        ornament3 = new CHOval();
        add(ornament3,0);
        ornament3.setBounds(580,180,20,20); 
        ornament3.setForeground(blue);
        ornament3.setBackground(blue);
         
           
        
        
        CHOval Oval;
        Oval = new CHOval();
        add(Oval,0);
        Oval.setBounds(25, 40, 80, 75); 
        Oval.setForeground(Transperant);
        Oval.setBackground(Transperant);
        
        
         CHArc topGlass;
        topGlass = new CHArc();
        add(topGlass, 0);
        topGlass.setBounds(25, 40, 80, 75);
        topGlass.setArc(45, 90);
        topGlass.setBackground(Transperant2);
        //Rectangle up = upbound.getBounds();
       

        jAction = new Jump();
        add(jAction);
        jAction.setDelay(50);
        
        jAction.setText("jump");
        jAction.setLimit(1000);
        
         Reset rAction;
        rAction = new Reset();
        add(rAction);
        //jAction.setAction(jAction);
        rAction.setText("Reset");
        //rAction.setLimit(100);
        
        moveornament move;
        move= new moveornament();
        add(move);
        move.setText("Move");
        move.setLimit(10000);
        
        CHButton jButton;
        jButton = new CHButton();
        add(jButton,0);
        jButton.setAction(jAction);
        //jButton.setText("Jump");
        jButton.setBounds(700, 305, 80, 30);   
        
         CHButton rButton;
        rButton = new CHButton();
        add(rButton,0);
        rButton.setAction(rAction);
        //jButton.setText("Jump");
        rButton.setBounds(70, 305, 80, 30);    
        
        
        
        
         CHButton mButton;
        mButton = new CHButton();
        add(mButton,0);
        mButton.setAction(move);
        //jButton.setText("");
        mButton.setBounds(70, 400, 80, 30);   
        
        
        
        
        count = 0;
        
       
        
        score1 = new CHLabel();
        add (score1,0);
        score1.setForeground(black);
        score1.setBounds(300,100,100,10);
        score1.setText("Score: " + count);
        
        
        
         
        //lava2.setBounds(-70, 500, 1300, 371);

        
 
    } // end of init - DO NOT REMOVE
    
    /***********************************************************
     * DO NOT Change anything below this line.
     ***********************************************************/
    public static void run() {
        int width = 900;
        int height = 700;
        CHApplet applet = new Bounce(); 
        applet.run(width, height);
    }
    
    private Bounce(){}
}
