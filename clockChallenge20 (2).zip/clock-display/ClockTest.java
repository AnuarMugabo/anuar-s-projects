import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ClockTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ClockTest
{
    private ClockDisplay clockDis1;

    /**
     * Default constructor for test class ClockTest
     */
    public ClockTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        clockDis1 = new ClockDisplay();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void initial()
    {
        assertEquals("00:00", clockDis1.getTime());
    }

    @Test
    public void set0815()
    {
        clockDis1.setTime(8, 15);
        assertEquals("08:15", clockDis1.getTime());
    }

    @Test
    public void set1145()
    {
        clockDis1.setTime(11, 45);
        assertEquals("11:45", clockDis1.getTime());
    }

    @Test
    public void set1938()
    {
        clockDis1.setTime(19, 38);
        assertEquals("19:38", clockDis1.getTime());
    }

    @Test
    public void set9999()
    {
        clockDis1.setTime(99, 99);
        String time = clockDis1.getTime();
        assertFalse(time.equals("99:99"));
    }

    @Test
    public void set9936()
    {
        clockDis1.setTime(99, 36);
        String time = clockDis1.getTime();
        assertFalse(time.equals("99:36"));
    }

    @Test
    public void set0799()
    {
        clockDis1.setTime(7, 99);
        String time = clockDis1.getTime();
        assertFalse(time.equals("07:99"));
    }

    @Test
    public void tickTo0001()
    {
        clockDis1.timeTick();
        assertEquals("00:01", clockDis1.getTime());
    }

    @Test
    public void tickTo0002()
    {
        clockDis1.timeTick();
        assertEquals("00:01", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("00:02", clockDis1.getTime());
    }

    @Test
    public void tickTo0201()
    {
        clockDis1.setTime(1, 58);
        assertEquals("01:58", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("01:59", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("02:00", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("02:01", clockDis1.getTime());
    }

    @Test
    public void tickTo1001()
    {
        clockDis1.setTime(9, 58);
        assertEquals("09:58", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("09:59", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("10:00", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("10:01", clockDis1.getTime());
    }

    @Test
    public void tickTo1301()
    {
        clockDis1.setTime(12, 58);
        assertEquals("12:58", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("12:59", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("13:00", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("13:01", clockDis1.getTime());
    }

    @Test
    public void tickAroundTo01()
    {
        clockDis1.setTime(23, 58);
        assertEquals("23:58", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("23:59", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("00:00", clockDis1.getTime());
        clockDis1.timeTick();
        assertEquals("00:01", clockDis1.getTime());
    }
}
